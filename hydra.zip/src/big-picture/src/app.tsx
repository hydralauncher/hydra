import { Fragment, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import {
  BIG_PICTURE_APP_LAYER_ID,
  BIG_PICTURE_CONTENT_REGION_ID,
  BIG_PICTURE_SHELL_REGION_ID,
  getBigPictureContentEntryRegionIdFromPathname,
  BIG_PICTURE_SIDEBAR_ITEM_IDS,
  getBigPictureGameRouteMatch,
  getBigPictureSidebarLibraryGameFocusId,
  getBigPictureSidebarItemIdFromPathname,
  Header,
  Sidebar,
} from "./layout";
import { IS_DESKTOP } from "./constants";
import { useBigPictureToast, useNavigation, useUserPreferences } from "./hooks";
import {
  HorizontalFocusGroup,
  InputModeProvider,
  NavigationHistoryBridge,
  NavigationLayer,
  NavigationAutoScrollBridge,
  NavigationInputProvider,
  NavigationStateBridge,
  NavigationDiagnostics,
  VerticalFocusGroup,
  BigPictureToastHost,
  CloudGiftNotificationModal,
  MissingScreenshotsToast,
  ScreenshotUploadFailureToast,
  VirtualKeyboardProvider,
} from "./components";
import { getItemFocusTarget } from "./helpers";
import {
  initializeBigPictureRunningGamesStore,
  useInputModeStore,
} from "./stores";
import { NavigationAudioService, type FocusOverrides } from "./services";
import { BigPictureI18nBridge, ensureBigPictureI18nResources } from "./i18n";

import "./styles/globals.scss";

export default function App() {
  ensureBigPictureI18nResources();

  const { t } = useTranslation();
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { showErrorToast, showSuccessToast, showWarningToast } =
    useBigPictureToast();
  const { nodes, regions, setFocusRegion } = useNavigation();
  const userPreferences = useUserPreferences();
  const inputMode = useInputModeStore((state) => state.mode);
  const [pendingRouteFocusPathname, setPendingRouteFocusPathname] = useState<
    string | null
  >(pathname);
  const activeSidebarItemId = getBigPictureSidebarItemIdFromPathname(pathname);
  const activeGameRoute = getBigPictureGameRouteMatch(pathname);
  const leftSidebarTargetId = activeGameRoute
    ? getBigPictureSidebarLibraryGameFocusId(activeGameRoute)
    : (activeSidebarItemId ?? BIG_PICTURE_SIDEBAR_ITEM_IDS.library);
  const contentNavigationOverrides: FocusOverrides = {
    left: getItemFocusTarget(leftSidebarTargetId),
  };

  useEffect(() => {
    if (!IS_DESKTOP) {
      document.documentElement.style.colorScheme = "dark";
      return;
    }

    initializeBigPictureRunningGamesStore();
  }, []);

  useEffect(() => {
    if (!IS_DESKTOP) return;

    return globalThis.window.electron.onNavigate((path) => {
      if (path.startsWith("/big-picture")) {
        navigate(path);
      }
    });
  }, [navigate]);

  useEffect(() => {
    if (!IS_DESKTOP) return;

    const unsubscribeExtractionFailed =
      globalThis.window.electron.onExtractionFailed(
        (_shop, _objectId, failure) => {
          if (failure?.reason === "unsupported-format") {
            showErrorToast(
              t("extraction_unsupported_format_title", { ns: "downloads" }),
              {
                message: t("extraction_unsupported_format_description", {
                  ns: "downloads",
                  format: failure.format,
                }),
              }
            );
            return;
          }

          if (failure?.reason === "file-not-found") {
            showErrorToast(
              t("extraction_file_not_found_title", { ns: "downloads" }),
              {
                message: t("extraction_file_not_found_description", {
                  ns: "downloads",
                }),
              }
            );
            return;
          }

          showErrorToast(t("extraction_failed_title", { ns: "downloads" }), {
            message: t("extraction_failed_description", { ns: "downloads" }),
          });
        }
      );

    const unsubscribeExecutableNotFound =
      globalThis.window.electron.onGameExecutableNotFound(() => {
        showErrorToast(
          t("executable_not_found_title", { ns: "game_details" }),
          {
            message: t("executable_not_found_big_picture_description", {
              ns: "game_details",
            }),
          }
        );
      });

    const unsubscribeInstallerClosed =
      globalThis.window.electron.onGameInstallerClosed(
        (_shop, _objectId, executableFound) => {
          if (executableFound) {
            showSuccessToast(t("game_installed_title", { ns: "downloads" }), {
              message: t("game_installed_description", { ns: "downloads" }),
              fallbackVisual: "downloads",
            });
            return;
          }

          showWarningToast(
            t("installed_game_not_found_title", { ns: "downloads" }),
            {
              message: t("installed_game_not_found_description", {
                ns: "downloads",
              }),
              fallbackVisual: "downloads",
            }
          );
        }
      );

    return () => {
      unsubscribeExtractionFailed();
      unsubscribeExecutableNotFound();
      unsubscribeInstallerClosed();
    };
  }, [showErrorToast, showSuccessToast, showWarningToast, t]);

  useEffect(() => {
    setPendingRouteFocusPathname(pathname);
  }, [pathname]);

  useEffect(() => {
    if (pendingRouteFocusPathname !== pathname) return;

    const entryRegionId =
      getBigPictureContentEntryRegionIdFromPathname(pathname);
    if (!entryRegionId) return;

    const hasRegion = regions.some((region) => region.id === entryRegionId);
    if (!hasRegion) return;

    const focusedId = setFocusRegion(entryRegionId, "right", {
      preferRememberedFocus: false,
    });

    if (focusedId) {
      setPendingRouteFocusPathname(null);
    }
  }, [
    leftSidebarTargetId,
    nodes,
    pathname,
    pendingRouteFocusPathname,
    regions,
    setFocusRegion,
  ]);

  useEffect(() => {
    NavigationAudioService.getInstance().setEnabled(
      (userPreferences?.bigPictureSoundsEnabled ?? true) &&
        inputMode === "gamepad"
    );
  }, [userPreferences?.bigPictureSoundsEnabled, inputMode]);

  return (
    <Fragment>
      <NavigationStateBridge />
      <NavigationAutoScrollBridge />
      <NavigationHistoryBridge />

      <NavigationInputProvider>
        <div id="big-picture">
          <BigPictureI18nBridge />

          <NavigationLayer
            layerId={BIG_PICTURE_APP_LAYER_ID}
            rootRegionId={BIG_PICTURE_SHELL_REGION_ID}
            initialFocusRegionId={BIG_PICTURE_CONTENT_REGION_ID}
          >
            <HorizontalFocusGroup
              regionId={BIG_PICTURE_SHELL_REGION_ID}
              autoScrollMode="auto"
              asChild
            >
              <div className="big-picture__app">
                <Sidebar />

                <VerticalFocusGroup
                  regionId={BIG_PICTURE_CONTENT_REGION_ID}
                  navigationOverrides={contentNavigationOverrides}
                  autoScrollMode="auto"
                  asChild
                >
                  <div className="big-picture__layout">
                    <Header />

                    <article className="big-picture__content">
                      <Outlet />
                    </article>

                    <VirtualKeyboardProvider />
                  </div>
                </VerticalFocusGroup>
              </div>
            </HorizontalFocusGroup>
          </NavigationLayer>

          <InputModeProvider />
          <NavigationDiagnostics />
          <BigPictureToastHost />
          <CloudGiftNotificationModal />
          <MissingScreenshotsToast />
          <ScreenshotUploadFailureToast />
        </div>
      </NavigationInputProvider>
    </Fragment>
  );
}
