export const PROFILE_PAGE_REGION_ID = "profile-page";
export const PROFILE_HERO_ACTIONS_REGION_ID = "profile-hero-actions";
export const PROFILE_HERO_SIGN_OUT_BUTTON_ID = "profile-hero-sign-out";
export const PROFILE_HERO_EXTERNAL_PRIMARY_ACTION_ID =
  "profile-hero-external-primary";
export const PROFILE_HERO_EXTERNAL_SECONDARY_ACTION_ID =
  "profile-hero-external-secondary";
export const PROFILE_HERO_EXTERNAL_TERTIARY_ACTION_ID =
  "profile-hero-external-tertiary";
export const PROFILE_RECENT_ACTIVITY_REGION_ID = "profile-recent-activity";
export const PROFILE_LIBRARY_CAROUSEL_REGION_ID = "profile-library-carousel";
export const PROFILE_SOUVENIRS_REGION_ID = "profile-souvenirs";
export const PROFILE_SOCIAL_REGION_ID = "profile-social";
export const PROFILE_ACHIEVEMENTS_REGION_ID = "profile-achievements";
export const PROFILE_FRIENDS_REGION_ID = "profile-friends";
export const PROFILE_FRIENDS_VIEW_ALL_ID = "profile-friends-view-all";

export const getProfileActivityItemId = (gameKey: string) =>
  `profile-activity-${gameKey}`;

export const getProfileAchievementGameItemId = (gameKey: string) =>
  `profile-achievement-${gameKey}`;

export const getProfileFriendItemId = (friendId: string) =>
  `profile-friend-${friendId}`;

export function getProfileSouvenirItemId(souvenirKey: string) {
  return `profile-souvenir-${souvenirKey}`;
}

export const PROFILE_SCREENSHOTS_REGION_ID = "profile-screenshots";
export const PROFILE_SCREENSHOTS_CONTROLS_REGION_ID =
  "profile-screenshots-controls";
export const PROFILE_SCREENSHOTS_FILTER_ID = "profile-screenshots-filter";
export const PROFILE_SCREENSHOTS_SORT_ID = "profile-screenshots-sort";

export function getProfileScreenshotItemId(screenshotId: string) {
  return `profile-screenshot-${screenshotId}`;
}
export const PROFILE_SCREENSHOTS_RETRY_ID = "profile-screenshots-retry";
export const PROFILE_SCREENSHOTS_LOAD_MORE_RETRY_ID =
  "profile-screenshots-load-more-retry";
