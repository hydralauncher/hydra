import type {
  EmulationCloudSave,
  EmulationSavePlatform,
  MemcardFormatState,
  MemcardRestoreErrorReason,
  MemcardRestoreResult,
  MemcardRestoreTarget,
} from "@types";
import { useCallback, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";

import {
  Button,
  FocusItem,
  HorizontalFocusGroup,
  Modal,
  VerticalFocusGroup,
} from "../../../components";
import { useNavigation } from "../../../hooks";
import {
  getEmulationCloudRestoreButtonNavigationOverrides,
  getEmulationCloudRestoreTargetFocusId,
  getEmulationCloudRestoreTargetNavigationOverrides,
} from "../settings-navigation";
import { basename } from "./shared";

const PICK_FILTERS: Record<
  Extract<EmulationSavePlatform, "ps1" | "ps2">,
  { name: string; extensions: string[] }
> = {
  ps1: {
    name: "PS1 Memory Card",
    extensions: ["mcd", "mcr", "mc", "gme", "vgs", "vmp"],
  },
  ps2: { name: "PS2 Memory Card", extensions: ["ps2", "mcd", "mc2"] },
};

interface EmulationCloudRestoreModalProps {
  save: EmulationCloudSave | null;
  platform: EmulationSavePlatform;
  onClose: () => void;
  onRestored: () => void;
  onRestoreSuccess: (result: MemcardRestoreResult) => void;
  onRestoreError: (reason?: MemcardRestoreErrorReason) => void;
  regionId: string;
  actionsRegionId: string;
  pickButtonId: string;
  confirmButtonId: string;
  modalClassName?: string;
  formatPickedPathLabel?: (path: string) => string;
}

export function EmulationCloudRestoreModal({
  save,
  platform,
  onClose,
  onRestored,
  onRestoreSuccess,
  onRestoreError,
  regionId,
  actionsRegionId,
  pickButtonId,
  confirmButtonId,
  modalClassName,
  formatPickedPathLabel = basename,
}: Readonly<EmulationCloudRestoreModalProps>) {
  const { t } = useTranslation("settings");
  const { setFocus } = useNavigation();
  const [targets, setTargets] = useState<MemcardRestoreTarget[]>([]);
  const [selectedTarget, setSelectedTarget] = useState<string | null>(null);
  const [selectedFormat, setSelectedFormat] =
    useState<MemcardFormatState | null>(null);
  const [isBusy, setIsBusy] = useState(false);
  const isMemoryCardPlatform = platform === "ps1" || platform === "ps2";

  const unformattedKey =
    platform === "ps2"
      ? "cloud_restore_unformatted_ps2"
      : "cloud_restore_unformatted";

  useEffect(() => {
    if (!save) return;

    let cancelled = false;
    void globalThis.window.electron
      .getMemcardRestoreTargets(platform, save.metadata)
      .then((foundTargets) => {
        if (cancelled) return;
        setTargets(foundTargets);
        setSelectedTarget(foundTargets[0]?.cardFilePath ?? null);
      });

    return () => {
      cancelled = true;
    };
  }, [platform, save]);

  useEffect(() => {
    if (!selectedTarget) {
      setSelectedFormat(null);
      return;
    }

    if (!isMemoryCardPlatform) {
      setSelectedFormat("formatted");
      return;
    }

    let cancelled = false;
    setSelectedFormat(null);
    globalThis.window.electron
      .inspectMemcard(platform, selectedTarget)
      .then((state) => {
        if (!cancelled) setSelectedFormat(state);
      })
      .catch(() => {
        if (!cancelled) setSelectedFormat("unreadable");
      });

    return () => {
      cancelled = true;
    };
  }, [isMemoryCardPlatform, platform, selectedTarget]);

  useEffect(() => {
    if (!save) return;

    const frameId = globalThis.window.requestAnimationFrame(() => {
      setFocus(
        selectedTarget
          ? getEmulationCloudRestoreTargetFocusId(selectedTarget)
          : pickButtonId
      );
    });

    return () => {
      globalThis.window.cancelAnimationFrame(frameId);
    };
  }, [pickButtonId, save, selectedTarget, setFocus]);

  const handlePickFile = useCallback(async () => {
    if (!isMemoryCardPlatform) return;
    const filter = platform === "ps2" ? PICK_FILTERS.ps2 : PICK_FILTERS.ps1;
    const result = await globalThis.window.electron.showOpenDialog({
      properties: ["openFile"],
      filters: [filter],
    });

    if (result.canceled || result.filePaths.length === 0) return;

    const chosenPath = result.filePaths[0];
    setTargets((current) =>
      current.some((target) => target.cardFilePath === chosenPath)
        ? current
        : [
            ...current,
            {
              cardFilePath: chosenPath,
              cardLabel: formatPickedPathLabel(chosenPath),
            },
          ]
    );
    setSelectedTarget(chosenPath);
  }, [formatPickedPathLabel, isMemoryCardPlatform, platform]);

  const handleRestore = useCallback(async () => {
    if (!save || !selectedTarget) return;

    setIsBusy(true);

    try {
      const result = await globalThis.window.electron.restoreEmulationSave(
        platform,
        save.id,
        selectedTarget,
        save.metadata,
        save.fileName
      );

      if (result.ok) {
        onRestoreSuccess(result);
        onRestored();
        onClose();
      } else {
        onRestoreError(result.reason);
      }
    } finally {
      setIsBusy(false);
    }
  }, [
    onClose,
    onRestored,
    onRestoreError,
    onRestoreSuccess,
    platform,
    save,
    selectedTarget,
  ]);

  return (
    <Modal
      visible={save !== null}
      title={t(
        isMemoryCardPlatform
          ? "cloud_restore_title"
          : "cloud_restore_emulator_title"
      )}
      description={t(
        isMemoryCardPlatform
          ? "cloud_restore_description"
          : "cloud_restore_emulator_description"
      )}
      onClose={onClose}
      className={modalClassName}
    >
      <VerticalFocusGroup
        regionId={regionId}
        className="emu-save-modal__restore"
      >
        <div className="emu-save-modal__targets">
          {targets.length === 0 ? (
            <div className="emu-save-modal__empty">
              {t(
                isMemoryCardPlatform
                  ? "cloud_restore_no_cards"
                  : "cloud_restore_no_destination"
              )}
            </div>
          ) : (
            targets.map((target) => {
              const targetId = getEmulationCloudRestoreTargetFocusId(
                target.cardFilePath
              );
              const isSelected = selectedTarget === target.cardFilePath;

              return (
                <FocusItem
                  key={target.cardFilePath}
                  id={targetId}
                  navigationOverrides={getEmulationCloudRestoreTargetNavigationOverrides(
                    {
                      cardFilePath: target.cardFilePath,
                      firstCardFilePath: targets[0]?.cardFilePath,
                      lastCardFilePath: targets.at(-1)?.cardFilePath,
                      pickButtonId,
                    }
                  )}
                  asChild
                >
                  <button
                    type="button"
                    className={`emu-save-modal__target${
                      isSelected ? " emu-save-modal__target--selected" : ""
                    }`}
                    onClick={() => setSelectedTarget(target.cardFilePath)}
                  >
                    <span className="emu-save-modal__target-name">
                      {target.cardLabel}
                    </span>
                    <span className="emu-save-modal__target-path">
                      {target.cardFilePath}
                    </span>
                  </button>
                </FocusItem>
              );
            })
          )}
        </div>

        {selectedFormat === "unformatted" && (
          <p className="emu-save-modal__hint">{t(unformattedKey)}</p>
        )}

        <HorizontalFocusGroup
          regionId={actionsRegionId}
          className="emu-save-modal__actions"
        >
          {isMemoryCardPlatform && (
            <Button
              focusId={pickButtonId}
              focusNavigationOverrides={getEmulationCloudRestoreButtonNavigationOverrides(
                selectedTarget
              )}
              variant="secondary"
              disabled={isBusy}
              onClick={handlePickFile}
            >
              {t("cloud_restore_pick_file")}
            </Button>
          )}
          <Button
            focusId={confirmButtonId}
            focusNavigationOverrides={getEmulationCloudRestoreButtonNavigationOverrides(
              selectedTarget
            )}
            loading={isBusy}
            disabled={
              !selectedTarget ||
              !selectedFormat ||
              selectedFormat === "unformatted"
            }
            onClick={handleRestore}
          >
            {t(
              isMemoryCardPlatform
                ? "cloud_restore_confirm"
                : "cloud_restore_emulator_confirm"
            )}
          </Button>
        </HorizontalFocusGroup>
      </VerticalFocusGroup>
    </Modal>
  );
}
