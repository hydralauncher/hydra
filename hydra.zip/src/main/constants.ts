import { app } from "electron";
import path from "node:path";
import fs from "node:fs";
import { SystemPath } from "./services/system-path";

// Opt-in isolation for local API testing; packaged installs keep their paths.
const developmentUserDataPath = import.meta.env.MAIN_VITE_USER_DATA_PATH;
if (!app.isPackaged && developmentUserDataPath) {
  fs.mkdirSync(developmentUserDataPath, { recursive: true, mode: 0o700 });
  app.setPath("userData", developmentUserDataPath);
}

export const defaultDownloadsPath = SystemPath.getPath("downloads");

export const isStaging = import.meta.env.MAIN_VITE_API_URL.includes("staging");

export const windowsStartMenuPath = path.join(
  SystemPath.getPath("appData"),
  "Microsoft",
  "Windows",
  "Start Menu",
  "Programs"
);

export const publicProfilePath = "C:/Users/Public";

export const levelDatabasePath = path.join(
  SystemPath.getPath("userData"),
  `hydra-db${isStaging ? "-staging" : ""}`
);

export const commonRedistPath = path.join(
  SystemPath.getPath("userData"),
  "CommonRedist"
);

export const logsPath = path.join(
  SystemPath.getPath("userData"),
  `logs${isStaging ? "-staging" : ""}`
);

export const screenshotsPath = path.join(
  SystemPath.getPath("userData"),
  "Screenshots"
);

export const achievementSoundPath = app.isPackaged
  ? path.join(process.resourcesPath, "achievement.wav")
  : path.join(__dirname, "..", "..", "resources", "achievement.wav");

export const chatMessageSoundPath = app.isPackaged
  ? path.join(process.resourcesPath, "chat-message.wav")
  : path.join(
      __dirname,
      "..",
      "..",
      "src",
      "big-picture",
      "src",
      "assets",
      "audio",
      "Favorite Sound.wav"
    );

export const backupsPath = path.join(SystemPath.getPath("userData"), "Backups");

export const appVersion = app.getVersion() + (isStaging ? "-staging" : "");

export const ASSETS_PATH = path.join(SystemPath.getPath("userData"), "Assets");

export const THEMES_PATH = path.join(SystemPath.getPath("userData"), "themes");

export const INTERVALS = {
  processWatcher: 2_000,
  downloadWatcher: 2_000,
  debridReadinessWatcher: 5_000,
  achievementWatcher: 2_000,
  emulatorSouvenirWatcher: 500,
  seedStatusWatcher: 2_000,
  updateChecker: 60_000 * 50, // 50 minutes
  powerSaveBlockerSync: 20_000,
};

export const DEFAULT_ACHIEVEMENT_SOUND_VOLUME = 0.15;

export const SOUVENIR_RETRY_BASE_DELAY_MS = 10_000;
export const SOUVENIR_RETRY_MAX_DELAY_MS = 15 * 60_000;
export const SOUVENIR_TERMINAL_RETENTION_MS = 7 * 24 * 60 * 60_000;
export const SOUVENIR_PAUSED_RETENTION_MS = 30 * 24 * 60 * 60_000;
export const SOUVENIR_SYNC_METADATA_TIMEOUT_MS = 5_000;

export const DECKY_PLUGINS_LOCATION = path.join(
  SystemPath.getPath("home"),
  "homebrew",
  "plugins"
);

export const HYDRA_DECKY_PLUGIN_LOCATION = path.join(
  DECKY_PLUGINS_LOCATION,
  "Hydra"
);
