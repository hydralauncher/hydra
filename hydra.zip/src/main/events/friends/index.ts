import "./open-friends-window";
import "./open-friend-profile";
import "./open-add-friend-modal";
import "./friends-window-controls";
import "./sync-friend-requests";
import "./prefetch-friends";
import "./show-toast-in-main-window";
