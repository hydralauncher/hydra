import "./get-game-assets";
import "./get-game-shop-details";
import "./get-game-stats";
import "./get-catalogue-names";
import "./get-random-game";
import "./get-game-artwork";
import "./get-cover-poster";
